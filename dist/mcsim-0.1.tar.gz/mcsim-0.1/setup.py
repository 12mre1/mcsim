from setuptools import setup

setup(name='mcsim',
      version='0.1',
      description='Monte Carlo Simulation',
      packages=['mcsim'],
      author='Matthew Edwards',
      zip_safe=False)